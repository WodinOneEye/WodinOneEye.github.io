# RSSI Monitor

A small, local Windows desktop app that tracks the Wi-Fi connection in real time. It uses the built-in Windows Native Wi-Fi API; no packages, internet connection, telemetry, or admin access are required.

## Run

Install [Python 3 for Windows](https://www.python.org/downloads/windows/) if it is not already installed. During setup, select **Add python.exe to PATH**. Then open PowerShell in this folder and run:

```powershell
py -3 .\rssi_monitor.py
```

The app refreshes once per second and shows the connected SSID, BSSID, channel, signal percentage, link rates, and a rolling 60-second RSSI graph. It shows **RSSI** when the Wi-Fi adapter exposes measured dBm data. Otherwise it deliberately shows **Estimated RSSI** (≈) calculated from Windows' 0–100% signal quality; it does not represent that estimate as a hardware measurement.

You can also double-click `start_rssi_monitor.bat` after Python is installed.

## Notes

- RSSI is fetched from the access point's BSS entry, which Windows supplies when the adapter/driver exposes it. If a driver or Windows permissions do not provide it, the status line identifies the Windows API error and the display switches to the labelled estimate described above.
- The app supports the 2.4 GHz, 5 GHz, and 6 GHz channel ranges.
