@echo off
py -3 "%~dp0rssi_monitor.py"
