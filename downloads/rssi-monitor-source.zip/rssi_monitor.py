"""Local, live Wi-Fi RSSI monitor for Windows.

Uses the Windows Native Wi-Fi API directly, so it has no Python package
dependencies and does not send connection data anywhere.
"""

from __future__ import annotations

import ctypes
from ctypes import wintypes
from collections import deque
import math
import os
import time
import tkinter as tk
from tkinter import ttk


POLL_MS = 1000
HISTORY_SECONDS = 60

WLAN_INTF_OPCODE_CURRENT_CONNECTION = 7
WLAN_INTF_OPCODE_CHANNEL_NUMBER = 8
WLAN_INTERFACE_STATE_CONNECTED = 1
DOT11_BSS_TYPE_ANY = 3


class DOT11_SSID(ctypes.Structure):
    _fields_ = [("uSSIDLength", wintypes.DWORD), ("ucSSID", ctypes.c_ubyte * 32)]

    def text(self) -> str:
        return bytes(self.ucSSID[: self.uSSIDLength]).decode("utf-8", "replace")


class WLAN_INTERFACE_INFO(ctypes.Structure):
    _fields_ = [
        ("InterfaceGuid", ctypes.c_byte * 16),
        ("strInterfaceDescription", wintypes.WCHAR * 256),
        ("isState", wintypes.DWORD),
    ]


class WLAN_CONNECTION_ATTRIBUTES(ctypes.Structure):
    _fields_ = [
        ("isState", wintypes.DWORD),
        ("wlanConnectionMode", wintypes.DWORD),
        ("strProfileName", wintypes.WCHAR * 256),
        ("dot11Ssid", DOT11_SSID),
        ("dot11BssType", wintypes.DWORD),
        ("dot11Bssid", ctypes.c_ubyte * 6),
        ("dot11PhyType", wintypes.DWORD),
        ("uDot11PhyIndex", wintypes.DWORD),
        ("wlanSignalQuality", wintypes.DWORD),
        ("ulRxRate", wintypes.DWORD),
        ("ulTxRate", wintypes.DWORD),
        ("bSecurityEnabled", wintypes.BOOL),
        ("bOneXEnabled", wintypes.BOOL),
        ("dot11AuthAlgorithm", wintypes.DWORD),
        ("dot11CipherAlgorithm", wintypes.DWORD),
    ]


class WLAN_BSS_ENTRY(ctypes.Structure):
    _fields_ = [
        ("dot11Ssid", DOT11_SSID),
        ("uPhyId", wintypes.DWORD),
        ("dot11Bssid", ctypes.c_ubyte * 6),
        ("dot11BssType", wintypes.DWORD),
        ("dot11BssPhyType", wintypes.DWORD),
        ("lRssi", ctypes.c_long),
        ("uLinkQuality", wintypes.DWORD),
        ("bInRegDomain", wintypes.BOOL),
        ("usBeaconPeriod", wintypes.WORD),
        ("ullTimestamp", ctypes.c_ulonglong),
        ("ullHostTimestamp", ctypes.c_ulonglong),
        ("usCapabilityInformation", wintypes.WORD),
        ("ulChCenterFrequency", wintypes.DWORD),
        ("wlanRateSetLength", wintypes.DWORD),
        ("wlanRateSet", wintypes.WORD * 126),
        ("ulIeOffset", wintypes.DWORD),
        ("ulIeSize", wintypes.DWORD),
    ]


def _mac(value: object) -> str:
    return ":".join(f"{byte:02X}" for byte in value)


def estimated_rssi(signal_percent: int) -> float:
    """Windows maps Wi-Fi quality linearly from -100 dBm (0%) to -50 dBm (100%)."""
    return -100 + max(0, min(100, signal_percent)) / 2


class WifiReader:
    """Small ctypes wrapper around wlanapi.dll."""

    def __init__(self) -> None:
        if os.name != "nt":
            raise RuntimeError("This monitor requires Windows.")
        self.api = ctypes.WinDLL("wlanapi.dll")
        self.handle = wintypes.HANDLE()
        negotiated = wintypes.DWORD()
        result = self.api.WlanOpenHandle(2, None, ctypes.byref(negotiated), ctypes.byref(self.handle))
        if result:
            raise RuntimeError(f"Could not open the Windows Wi-Fi API (error {result}).")

    def close(self) -> None:
        if self.handle:
            self.api.WlanCloseHandle(self.handle, None)
            self.handle = None

    def _interfaces(self) -> list[WLAN_INTERFACE_INFO]:
        pointer = ctypes.c_void_p()
        result = self.api.WlanEnumInterfaces(self.handle, None, ctypes.byref(pointer))
        if result:
            raise RuntimeError(f"Could not enumerate Wi-Fi adapters (error {result}).")
        try:
            count = ctypes.cast(pointer, ctypes.POINTER(wintypes.DWORD))[0]
            offset = ctypes.sizeof(wintypes.DWORD) * 2
            item_size = ctypes.sizeof(WLAN_INTERFACE_INFO)
            return [
                WLAN_INTERFACE_INFO.from_buffer_copy(ctypes.string_at(pointer.value + offset + i * item_size, item_size))
                for i in range(count)
            ]
        finally:
            self.api.WlanFreeMemory(pointer)

    def _query_connection(self, interface: WLAN_INTERFACE_INFO) -> WLAN_CONNECTION_ATTRIBUTES | None:
        data_size = wintypes.DWORD()
        data = ctypes.c_void_p()
        value_type = wintypes.DWORD()
        result = self.api.WlanQueryInterface(
            self.handle, ctypes.byref(interface.InterfaceGuid), WLAN_INTF_OPCODE_CURRENT_CONNECTION,
            None, ctypes.byref(data_size), ctypes.byref(data), ctypes.byref(value_type), None,
        )
        if result or not data:
            return None
        try:
            result_value = WLAN_CONNECTION_ATTRIBUTES.from_buffer_copy(
                ctypes.string_at(data, ctypes.sizeof(WLAN_CONNECTION_ATTRIBUTES))
            )
            return result_value if result_value.isState == WLAN_INTERFACE_STATE_CONNECTED else None
        finally:
            self.api.WlanFreeMemory(data)

    def _query_channel(self, interface: WLAN_INTERFACE_INFO) -> tuple[int | None, str | None]:
        """Ask the adapter for its current channel without triggering a BSS scan."""
        data_size = wintypes.DWORD()
        data = ctypes.c_void_p()
        value_type = wintypes.DWORD()
        result = self.api.WlanQueryInterface(
            self.handle, ctypes.byref(interface.InterfaceGuid), WLAN_INTF_OPCODE_CHANNEL_NUMBER,
            None, ctypes.byref(data_size), ctypes.byref(data), ctypes.byref(value_type), None,
        )
        if result or not data or data_size.value < ctypes.sizeof(wintypes.DWORD):
            return None, f"Windows Wi-Fi API error {result}" if result else "No channel data returned"
        try:
            return ctypes.cast(data, ctypes.POINTER(wintypes.DWORD))[0], None
        finally:
            self.api.WlanFreeMemory(data)

    def _rssi(self, interface: WLAN_INTERFACE_INFO, connection: WLAN_CONNECTION_ATTRIBUTES) -> tuple[int | None, str | None]:
        """Read adapter RSSI from the BSS list, if the driver permits that detail."""
        data = ctypes.c_void_p()
        result = self.api.WlanGetNetworkBssList(
            self.handle, ctypes.byref(interface.InterfaceGuid), ctypes.byref(connection.dot11Ssid),
            connection.dot11BssType or DOT11_BSS_TYPE_ANY, False, None, ctypes.byref(data),
        )
        if result or not data:
            return None, f"Windows Wi-Fi API error {result}" if result else "No BSS data returned"
        try:
            count = ctypes.cast(data, ctypes.POINTER(wintypes.DWORD))[0]
            offset = ctypes.sizeof(wintypes.DWORD) * 2
            size = ctypes.sizeof(WLAN_BSS_ENTRY)
            target = _mac(connection.dot11Bssid)
            for index in range(count):
                entry = WLAN_BSS_ENTRY.from_buffer_copy(ctypes.string_at(data.value + offset + index * size, size))
                if _mac(entry.dot11Bssid) == target:
                    return entry.lRssi, None
            return None, "The Wi-Fi driver did not return the active access point in its BSS list"
        finally:
            self.api.WlanFreeMemory(data)

    def sample(self) -> dict[str, object] | None:
        for interface in self._interfaces():
            connection = self._query_connection(interface)
            if connection:
                rssi, rssi_detail = self._rssi(interface, connection)
                channel, channel_detail = self._query_channel(interface)
                signal = int(connection.wlanSignalQuality)
                return {
                    "adapter": interface.strInterfaceDescription,
                    "ssid": connection.dot11Ssid.text() or "Hidden network",
                    "bssid": _mac(connection.dot11Bssid),
                    "rssi": rssi,
                    "estimated_rssi": estimated_rssi(signal),
                    "rssi_detail": rssi_detail,
                    "signal": signal,
                    "rx": int(connection.ulRxRate),
                    "tx": int(connection.ulTxRate),
                    "channel": str(channel) if channel is not None else "—",
                    "channel_detail": channel_detail,
                }
        return None


def rate_label(kbps: int) -> str:
    if kbps <= 0:
        return "—"
    return f"{kbps / 1000:.1f} Mbps"


def quality(signal: int) -> tuple[str, str]:
    if signal >= 75:
        return "Excellent", "#38d996"
    if signal >= 50:
        return "Good", "#a3df4b"
    if signal >= 30:
        return "Fair", "#ffc857"
    return "Weak", "#ff6b6b"


class MonitorApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("RSSI Monitor")
        self.geometry("980x650")
        self.minsize(760, 520)
        self.configure(bg="#10151f")
        self.reader: WifiReader | None = None
        self.history: deque[float] = deque(maxlen=HISTORY_SECONDS)
        self.started = time.monotonic()
        self.values: dict[str, tk.StringVar] = {}
        self._style()
        self._build()
        try:
            self.reader = WifiReader()
        except Exception as error:
            self.status.set(str(error))
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(100, self.refresh)

    def _style(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#10151f")
        style.configure("Card.TFrame", background="#19202d")
        style.configure("Heading.TLabel", background="#10151f", foreground="#f4f7fb", font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", background="#10151f", foreground="#98a4b5", font=("Segoe UI", 10))
        style.configure("CardLabel.TLabel", background="#19202d", foreground="#99a8bc", font=("Segoe UI", 10))
        style.configure("CardValue.TLabel", background="#19202d", foreground="#f6f8fc", font=("Segoe UI", 16, "bold"))
        style.configure("Big.TLabel", background="#19202d", foreground="#f6f8fc", font=("Segoe UI", 38, "bold"))

    def _build(self) -> None:
        main = ttk.Frame(self, padding=24)
        main.pack(fill="both", expand=True)
        main.columnconfigure(0, weight=1)
        main.columnconfigure(1, weight=1)
        main.columnconfigure(2, weight=1)
        main.rowconfigure(3, weight=1)

        ttk.Label(main, text="Wi-Fi RSSI", style="Heading.TLabel").grid(row=0, column=0, sticky="w")
        self.status = tk.StringVar(value="Connecting to Windows Wi-Fi service…")
        ttk.Label(main, textvariable=self.status, style="Sub.TLabel").grid(row=0, column=1, columnspan=2, sticky="e")

        signal_card = ttk.Frame(main, style="Card.TFrame", padding=18)
        signal_card.grid(row=1, column=0, sticky="nsew", padx=(0, 10), pady=(22, 10))
        self.rssi_caption = tk.StringVar(value="RSSI")
        ttk.Label(signal_card, textvariable=self.rssi_caption, style="CardLabel.TLabel").pack(anchor="w")
        self.rssi = tk.StringVar(value="— dBm")
        ttk.Label(signal_card, textvariable=self.rssi, style="Big.TLabel").pack(anchor="w", pady=(4, 0))
        self.quality_label = tk.StringVar(value="Waiting for signal")
        self.quality_dot = tk.Label(signal_card, textvariable=self.quality_label, bg="#19202d", fg="#98a4b5", font=("Segoe UI", 10, "bold"))
        self.quality_dot.pack(anchor="w", pady=(4, 0))

        identity = ttk.Frame(main, style="Card.TFrame", padding=18)
        identity.grid(row=1, column=1, columnspan=2, sticky="nsew", pady=(22, 10))
        self._item(identity, "NETWORK", "ssid")
        self._item(identity, "BSSID", "bssid")
        self._item(identity, "CHANNEL", "channel")

        for column, (label, key) in enumerate((("SIGNAL", "signal"), ("RECEIVE RATE", "rx"), ("TRANSMIT RATE", "tx"))):
            card = ttk.Frame(main, style="Card.TFrame", padding=18)
            card.grid(row=2, column=column, sticky="nsew", padx=(0, 10) if column < 2 else 0, pady=(0, 10))
            ttk.Label(card, text=label, style="CardLabel.TLabel").pack(anchor="w")
            var = tk.StringVar(value="—")
            self.values[key] = var
            ttk.Label(card, textvariable=var, style="CardValue.TLabel").pack(anchor="w", pady=(6, 0))

        graph_card = ttk.Frame(main, style="Card.TFrame", padding=18)
        graph_card.grid(row=3, column=0, columnspan=3, sticky="nsew")
        graph_card.columnconfigure(0, weight=1)
        graph_card.rowconfigure(1, weight=1)
        self.graph_caption = tk.StringVar(value="RSSI — LAST 60 SECONDS")
        ttk.Label(graph_card, textvariable=self.graph_caption, style="CardLabel.TLabel").grid(row=0, column=0, sticky="w")
        self.summary = tk.StringVar(value="Collecting readings…")
        ttk.Label(graph_card, textvariable=self.summary, style="CardLabel.TLabel").grid(row=0, column=0, sticky="e")
        self.canvas = tk.Canvas(graph_card, bg="#19202d", highlightthickness=0)
        self.canvas.grid(row=1, column=0, sticky="nsew", pady=(12, 0))
        self.canvas.bind("<Configure>", lambda _: self.draw_graph())

    def _item(self, parent: ttk.Frame, label: str, key: str) -> None:
        ttk.Label(parent, text=label, style="CardLabel.TLabel").pack(anchor="w")
        value = tk.StringVar(value="—")
        self.values[key] = value
        ttk.Label(parent, textvariable=value, style="CardValue.TLabel").pack(anchor="w", pady=(2, 9))

    def refresh(self) -> None:
        try:
            sample = self.reader.sample() if self.reader else None
            if sample:
                signal = int(sample["signal"])
                measured_rssi = sample["rssi"]
                rssi = float(measured_rssi if measured_rssi is not None else sample["estimated_rssi"])
                is_estimate = measured_rssi is None
                label, color = quality(signal)
                self.rssi_caption.set("ESTIMATED RSSI" if is_estimate else "RSSI")
                self.graph_caption.set("ESTIMATED RSSI — LAST 60 SECONDS" if is_estimate else "RSSI — LAST 60 SECONDS")
                self.rssi.set(f"≈ {rssi:.0f} dBm" if is_estimate else f"{rssi:.0f} dBm")
                self.quality_label.set(f"●  {label}")
                self.quality_dot.configure(fg="#ffc857" if is_estimate else color)
                if is_estimate:
                    detail = str(sample["rssi_detail"] or "Driver does not expose raw RSSI")
                    self.status.set(f"Live • estimated from Windows signal quality • {detail}")
                else:
                    self.status.set(f"Live • measured RSSI • updated {time.strftime('%I:%M:%S %p').lstrip('0')}")
                self.values["ssid"].set(str(sample["ssid"]))
                self.values["bssid"].set(str(sample["bssid"]))
                self.values["channel"].set(str(sample["channel"]))
                self.values["signal"].set(f"{signal}%")
                self.values["rx"].set(rate_label(int(sample["rx"])))
                self.values["tx"].set(rate_label(int(sample["tx"])))
                self.history.append(rssi)
                values = list(self.history)
                if values:
                    prefix = "Estimated " if is_estimate else ""
                    self.summary.set(f"{prefix}Best {max(values):.0f} dBm   Average {sum(values) / len(values):.1f} dBm   Worst {min(values):.0f} dBm")
            else:
                self.status.set("No connected Wi-Fi network found")
        except Exception as error:
            self.status.set(f"Wi-Fi read error: {error}")
        self.draw_graph()
        self.after(POLL_MS, self.refresh)

    def draw_graph(self) -> None:
        canvas = self.canvas
        canvas.delete("all")
        width, height = canvas.winfo_width(), canvas.winfo_height()
        if width < 10 or height < 10:
            return
        left, right, top, bottom = 44, 14, 12, 24
        graph_width, graph_height = width - left - right, height - top - bottom
        low, high = -95, -30
        for rssi in (-30, -50, -70, -90):
            y = top + (high - rssi) / (high - low) * graph_height
            canvas.create_line(left, y, width - right, y, fill="#2d3748", dash=(3, 4))
            canvas.create_text(left - 8, y, text=str(rssi), fill="#7f8ca0", anchor="e", font=("Segoe UI", 8))
        canvas.create_text(left, height - 8, text="60s ago", fill="#7f8ca0", anchor="w", font=("Segoe UI", 8))
        canvas.create_text(width - right, height - 8, text="now", fill="#7f8ca0", anchor="e", font=("Segoe UI", 8))
        if len(self.history) < 2:
            canvas.create_text(width / 2, height / 2, text="Waiting for Wi-Fi RSSI readings…", fill="#7f8ca0", font=("Segoe UI", 11))
            return
        values = list(self.history)
        points = []
        for index, value in enumerate(values):
            x = left + index / (HISTORY_SECONDS - 1) * graph_width
            y = top + (high - max(low, min(high, value))) / (high - low) * graph_height
            points.extend((x, y))
        canvas.create_line(*points, fill="#39d98a", width=2, smooth=True)
        x, y = points[-2:]
        canvas.create_oval(x - 4, y - 4, x + 4, y + 4, fill="#39d98a", outline="#19202d", width=2)

    def on_close(self) -> None:
        if self.reader:
            self.reader.close()
        self.destroy()


if __name__ == "__main__":
    MonitorApp().mainloop()
